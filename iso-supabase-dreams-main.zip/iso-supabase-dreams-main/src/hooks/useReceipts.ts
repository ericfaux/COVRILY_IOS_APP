import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface Receipt {
  id: string;
  merchant: string | null;
  purchase_date: string | null;
  total_cents: number | null;
  tax_cents: number | null;
  subtotal_cents: number | null;
  shipping_cents: number | null;
  order_id: string;
  channel: string | null;
  currency: string | null;
  created_at: string | null;
  raw_url: string | null;
}

export function useReceipts() {
  return useQuery({
    queryKey: ["receipts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("receipts")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) {
        throw error;
      }

      return data as Receipt[];
    },
  });
}

export function useReceiptStats() {
  return useQuery({
    queryKey: ["receipt-stats"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("receipts")
        .select("total_cents");

      if (error) {
        throw error;
      }

      const totalSpent = data.reduce((sum, receipt) => 
        sum + (receipt.total_cents || 0), 0
      );

      return {
        totalReceipts: data.length,
        totalSpent,
        averageSpend: data.length > 0 ? totalSpent / data.length : 0,
      };
    },
  });
}