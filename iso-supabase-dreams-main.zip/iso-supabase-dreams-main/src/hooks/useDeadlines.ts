import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface Deadline {
  id: string;
  type: string | null;
  status: string | null;
  due_at: string | null;
  receipt_id: string | null;
  created_at: string;
  decision: string | null;
  decision_note: string | null;
}

export function useUpcomingDeadlines() {
  return useQuery({
    queryKey: ["upcoming-deadlines"],
    queryFn: async () => {
      const now = new Date();
      const thirtyDaysFromNow = new Date();
      thirtyDaysFromNow.setDate(now.getDate() + 30);

      const { data, error } = await supabase
        .from("deadlines")
        .select(`
          *,
          receipts(merchant, purchase_date, total_cents)
        `)
        .eq("status", "open")
        .gte("due_at", now.toISOString())
        .lte("due_at", thirtyDaysFromNow.toISOString())
        .order("due_at", { ascending: true })
        .limit(10);

      if (error) {
        throw error;
      }

      return data;
    },
  });
}