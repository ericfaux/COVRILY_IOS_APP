import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, AlertTriangle, CheckCircle, Store } from "lucide-react";

interface DeadlineCardProps {
  deadline: any; // Using any for now since the type includes joined receipts data
}

export function DeadlineCard({ deadline }: DeadlineCardProps) {
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "No deadline";
    const date = new Date(dateString);
    const now = new Date();
    const diffDays = Math.ceil((date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    const formatted = date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });

    if (diffDays < 0) return `${formatted} (Expired)`;
    if (diffDays === 0) return `${formatted} (Due Today)`;
    if (diffDays === 1) return `${formatted} (Due Tomorrow)`;
    return `${formatted} (${diffDays} days)`;
  };

  const getUrgencyColor = (dueAt: string | null) => {
    if (!dueAt) return 'bg-muted text-muted-foreground';
    
    const date = new Date(dueAt);
    const now = new Date();
    const diffDays = Math.ceil((date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return 'bg-destructive text-destructive-foreground';
    if (diffDays <= 3) return 'bg-warning text-warning-foreground';
    if (diffDays <= 7) return 'bg-warning/60 text-warning-foreground';
    return 'bg-success/20 text-success-foreground';
  };

  const getUrgencyIcon = (dueAt: string | null) => {
    if (!dueAt) return <Clock className="h-4 w-4" />;
    
    const date = new Date(dueAt);
    const now = new Date();
    const diffDays = Math.ceil((date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 3) return <AlertTriangle className="h-4 w-4" />;
    return <Clock className="h-4 w-4" />;
  };

  const formatCurrency = (cents: number | null) => {
    if (!cents) return "$0.00";
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(cents / 100);
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Store className="h-4 w-4 text-muted-foreground" />
            <h3 className="font-semibold text-card-foreground">
              {deadline.receipts?.merchant || "Unknown Merchant"}
            </h3>
          </div>
          <Badge variant="secondary" className={getUrgencyColor(deadline.due_at)}>
            {deadline.type || "Return"}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2">
          {getUrgencyIcon(deadline.due_at)}
          <span className="text-sm font-medium">
            {formatDate(deadline.due_at)}
          </span>
        </div>

        {deadline.receipts?.total_cents && (
          <div className="text-sm text-muted-foreground">
            Purchase Amount: {formatCurrency(deadline.receipts.total_cents)}
          </div>
        )}

        {deadline.receipts?.purchase_date && (
          <div className="text-sm text-muted-foreground">
            Purchased: {new Date(deadline.receipts.purchase_date).toLocaleDateString()}
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <Button size="sm" variant="default" className="flex-1">
            <CheckCircle className="h-3 w-3 mr-1" />
            Take Action
          </Button>
          <Button size="sm" variant="outline" className="flex-1">
            View Receipt
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}