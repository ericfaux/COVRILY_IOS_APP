import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Receipt } from "@/hooks/useReceipts";
import { Calendar, DollarSign, Store, Package } from "lucide-react";

interface ReceiptCardProps {
  receipt: Receipt;
}

export function ReceiptCard({ receipt }: ReceiptCardProps) {
  const formatCurrency = (cents: number | null) => {
    if (!cents) return "$0.00";
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: receipt.currency || 'USD',
    }).format(cents / 100);
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Unknown date";
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const getChannelColor = (channel: string | null) => {
    switch (channel?.toLowerCase()) {
      case 'email':
        return 'bg-primary/10 text-primary';
      case 'manual':
        return 'bg-secondary/10 text-secondary-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Store className="h-4 w-4 text-muted-foreground" />
            <h3 className="font-semibold text-card-foreground">
              {receipt.merchant || "Unknown Merchant"}
            </h3>
          </div>
          {receipt.channel && (
            <Badge variant="secondary" className={getChannelColor(receipt.channel)}>
              {receipt.channel}
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4" />
            {formatDate(receipt.purchase_date)}
          </div>
          <div className="flex items-center gap-1">
            <DollarSign className="h-4 w-4 text-success" />
            <span className="font-semibold text-success">
              {formatCurrency(receipt.total_cents)}
            </span>
          </div>
        </div>

        {receipt.order_id && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Package className="h-4 w-4" />
            <span>Order: {receipt.order_id}</span>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4 text-xs text-muted-foreground border-t pt-3">
          {receipt.subtotal_cents && (
            <div>
              <span>Subtotal: </span>
              <span>{formatCurrency(receipt.subtotal_cents)}</span>
            </div>
          )}
          {receipt.tax_cents && (
            <div>
              <span>Tax: </span>
              <span>{formatCurrency(receipt.tax_cents)}</span>
            </div>
          )}
          {receipt.shipping_cents && (
            <div>
              <span>Shipping: </span>
              <span>{formatCurrency(receipt.shipping_cents)}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}