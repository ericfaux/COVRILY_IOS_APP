export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      amazon_orders: {
        Row: {
          order_number: string
          product_name_short: string | null
          return_html: string | null
          return_or_replace_date: string | null
          total_total_amount: number | null
          user_id: string
        }
        Insert: {
          order_number: string
          product_name_short?: string | null
          return_html?: string | null
          return_or_replace_date?: string | null
          total_total_amount?: number | null
          user_id: string
        }
        Update: {
          order_number?: string
          product_name_short?: string | null
          return_html?: string | null
          return_or_replace_date?: string | null
          total_total_amount?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "amazon_orders_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      approved_merchants: {
        Row: {
          merchant: string
          user_id: string
        }
        Insert: {
          merchant: string
          user_id: string
        }
        Update: {
          merchant?: string
          user_id?: string
        }
        Relationships: []
      }
      auth_merchants: {
        Row: {
          inserted_at: string | null
          merchant: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          inserted_at?: string | null
          merchant: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          inserted_at?: string | null
          merchant?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      claims: {
        Row: {
          id: string
          payload: Json | null
          receipt_id: string | null
          status: string | null
          submitted_at: string | null
          type: string | null
          user_id: string
        }
        Insert: {
          id?: string
          payload?: Json | null
          receipt_id?: string | null
          status?: string | null
          submitted_at?: string | null
          type?: string | null
          user_id: string
        }
        Update: {
          id?: string
          payload?: Json | null
          receipt_id?: string | null
          status?: string | null
          submitted_at?: string | null
          type?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "claims_receipt_id_fkey"
            columns: ["receipt_id"]
            isOneToOne: false
            referencedRelation: "receipts"
            referencedColumns: ["id"]
          },
        ]
      }
      deadlines: {
        Row: {
          closed_at: string | null
          created_at: string
          decision: string | null
          decision_note: string | null
          due_at: string | null
          heads_up_notified_at: string | null
          id: string
          last_notified_at: string | null
          receipt_id: string | null
          source_policy_id: string | null
          status: string | null
          type: string | null
          user_id: string
        }
        Insert: {
          closed_at?: string | null
          created_at?: string
          decision?: string | null
          decision_note?: string | null
          due_at?: string | null
          heads_up_notified_at?: string | null
          id?: string
          last_notified_at?: string | null
          receipt_id?: string | null
          source_policy_id?: string | null
          status?: string | null
          type?: string | null
          user_id: string
        }
        Update: {
          closed_at?: string | null
          created_at?: string
          decision?: string | null
          decision_note?: string | null
          due_at?: string | null
          heads_up_notified_at?: string | null
          id?: string
          last_notified_at?: string | null
          receipt_id?: string | null
          source_policy_id?: string | null
          status?: string | null
          type?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "deadlines_receipt_id_fkey"
            columns: ["receipt_id"]
            isOneToOne: false
            referencedRelation: "receipts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deadlines_source_policy_id_fkey"
            columns: ["source_policy_id"]
            isOneToOne: false
            referencedRelation: "policies"
            referencedColumns: ["id"]
          },
        ]
      }
      decisions: {
        Row: {
          created_at: string | null
          decision: string
          delta_cents: number | null
          id: string
          notes: string | null
          receipt_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          decision: string
          delta_cents?: number | null
          id?: string
          notes?: string | null
          receipt_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          decision?: string
          delta_cents?: number | null
          id?: string
          notes?: string | null
          receipt_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "decisions_receipt_id_fkey"
            columns: ["receipt_id"]
            isOneToOne: false
            referencedRelation: "receipts"
            referencedColumns: ["id"]
          },
        ]
      }
      gmail_tokens: {
        Row: {
          access_token: string | null
          access_token_expires_at: string | null
          granted_scopes: string[] | null
          reauth_required: boolean | null
          refresh_token: string | null
          status: string | null
          user_id: string
        }
        Insert: {
          access_token?: string | null
          access_token_expires_at?: string | null
          granted_scopes?: string[] | null
          reauth_required?: boolean | null
          refresh_token?: string | null
          status?: string | null
          user_id: string
        }
        Update: {
          access_token?: string | null
          access_token_expires_at?: string | null
          granted_scopes?: string[] | null
          reauth_required?: boolean | null
          refresh_token?: string | null
          status?: string | null
          user_id?: string
        }
        Relationships: []
      }
      inbound_emails: {
        Row: {
          created_at: string | null
          error: string | null
          id: string
          payload: Json | null
          processed_at: string | null
          provider: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          error?: string | null
          id?: string
          payload?: Json | null
          processed_at?: string | null
          provider?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          error?: string | null
          id?: string
          payload?: Json | null
          processed_at?: string | null
          provider?: string | null
          user_id?: string
        }
        Relationships: []
      }
      line_items: {
        Row: {
          id: string
          name: string | null
          product_id: string | null
          qty: number | null
          receipt_id: string | null
          unit_cents: number | null
        }
        Insert: {
          id?: string
          name?: string | null
          product_id?: string | null
          qty?: number | null
          receipt_id?: string | null
          unit_cents?: number | null
        }
        Update: {
          id?: string
          name?: string | null
          product_id?: string | null
          qty?: number | null
          receipt_id?: string | null
          unit_cents?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "line_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "line_items_receipt_id_fkey"
            columns: ["receipt_id"]
            isOneToOne: false
            referencedRelation: "receipts"
            referencedColumns: ["id"]
          },
        ]
      }
      merchant_master_data: {
        Row: {
          created_at: string | null
          merchant_id: string
          merchant_name: string
          policy_id: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          merchant_id?: string
          merchant_name: string
          policy_id?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          merchant_id?: string
          merchant_name?: string
          policy_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "merchant_master_data_policy_id_fkey"
            columns: ["policy_id"]
            isOneToOne: false
            referencedRelation: "policies"
            referencedColumns: ["id"]
          },
        ]
      }
      pending_receipts: {
        Row: {
          created_at: string | null
          from_header: string | null
          id: string
          merchant: string | null
          message_id: string | null
          status_code: number | null
          subject: string | null
          url: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          from_header?: string | null
          id?: string
          merchant?: string | null
          message_id?: string | null
          status_code?: number | null
          subject?: string | null
          url: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          from_header?: string | null
          id?: string
          merchant?: string | null
          message_id?: string | null
          status_code?: number | null
          subject?: string | null
          url?: string
          user_id?: string | null
        }
        Relationships: []
      }
      policies: {
        Row: {
          id: string
          last_reviewed_at: string | null
          merchant: string | null
          rules: Json | null
          type: string | null
        }
        Insert: {
          id?: string
          last_reviewed_at?: string | null
          merchant?: string | null
          rules?: Json | null
          type?: string | null
        }
        Update: {
          id?: string
          last_reviewed_at?: string | null
          merchant?: string | null
          rules?: Json | null
          type?: string | null
        }
        Relationships: []
      }
      price_observations: {
        Row: {
          created_at: string | null
          id: string
          observed_price_cents: number
          raw_excerpt: string | null
          receipt_id: string
          source: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          observed_price_cents: number
          raw_excerpt?: string | null
          receipt_id: string
          source: string
        }
        Update: {
          created_at?: string | null
          id?: string
          observed_price_cents?: number
          raw_excerpt?: string | null
          receipt_id?: string
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "price_observations_receipt_id_fkey"
            columns: ["receipt_id"]
            isOneToOne: false
            referencedRelation: "receipts"
            referencedColumns: ["id"]
          },
        ]
      }
      product_links: {
        Row: {
          active: boolean | null
          created_at: string | null
          last_notified_at: string | null
          merchant_hint: string | null
          receipt_id: string
          selector: string | null
          updated_at: string | null
          url: string
        }
        Insert: {
          active?: boolean | null
          created_at?: string | null
          last_notified_at?: string | null
          merchant_hint?: string | null
          receipt_id: string
          selector?: string | null
          updated_at?: string | null
          url: string
        }
        Update: {
          active?: boolean | null
          created_at?: string | null
          last_notified_at?: string | null
          merchant_hint?: string | null
          receipt_id?: string
          selector?: string | null
          updated_at?: string | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_links_receipt_id_fkey"
            columns: ["receipt_id"]
            isOneToOne: true
            referencedRelation: "receipts"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          brand: string | null
          category: string | null
          created_at: string | null
          id: string
          model: string | null
          serial: string | null
          upc: string | null
          user_id: string
        }
        Insert: {
          brand?: string | null
          category?: string | null
          created_at?: string | null
          id?: string
          model?: string | null
          serial?: string | null
          upc?: string | null
          user_id: string
        }
        Update: {
          brand?: string | null
          category?: string | null
          created_at?: string | null
          id?: string
          model?: string | null
          serial?: string | null
          upc?: string | null
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string | null
          email: string
          full_name: string | null
          id: string
          timezone: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          email: string
          full_name?: string | null
          id: string
          timezone?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          email?: string
          full_name?: string | null
          id?: string
          timezone?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      push_tokens: {
        Row: {
          created_at: string | null
          id: string
          token: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          token?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          token?: string | null
          user_id?: string
        }
        Relationships: []
      }
      receipts: {
        Row: {
          channel: string | null
          created_at: string | null
          currency: string | null
          id: string
          merchant: string | null
          order_id: string
          purchase_date: string | null
          raw_json: Json | null
          raw_url: string | null
          shipping_cents: number | null
          subtotal_cents: number | null
          tax_cents: number | null
          total_cents: number | null
          user_id: string
        }
        Insert: {
          channel?: string | null
          created_at?: string | null
          currency?: string | null
          id?: string
          merchant?: string | null
          order_id?: string
          purchase_date?: string | null
          raw_json?: Json | null
          raw_url?: string | null
          shipping_cents?: number | null
          subtotal_cents?: number | null
          tax_cents?: number | null
          total_cents?: number | null
          user_id: string
        }
        Update: {
          channel?: string | null
          created_at?: string | null
          currency?: string | null
          id?: string
          merchant?: string | null
          order_id?: string
          purchase_date?: string | null
          raw_json?: Json | null
          raw_url?: string | null
          shipping_cents?: number | null
          subtotal_cents?: number | null
          tax_cents?: number | null
          total_cents?: number | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
